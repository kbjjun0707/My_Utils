#include <glm/gtc/type_precision.hpp>
#include <glm/gtx/associated_min_max.hpp>

int main()
{
	int Error(0);

	return Error;
}
